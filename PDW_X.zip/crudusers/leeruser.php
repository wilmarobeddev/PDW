<div id="leeruser" tabindex="-1" role="dialog" class="modal fade" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">

        <!-- Modal content-->
        <div class="modal-content">

            <div class="modal-header">
                    <h5>VER REGISTRO </h5>
                    <a href="?" type="button" class="close"><span aria-hidden="true">&times;</span></a>
            </div>
            <div class="modal-body">

                <form class="form alert alert-success" action="#" method="POST" role="form">


                    <div class="form-group">
                        <input class="form-control" type="hidden" name="id" id="id1">
                    </div>
                    <div class="row">
                        <div class="form-group col-6 content-justify">
                            <label for="">Nombres</label>
                            <input style="color:black; background:beige;" class="form-control" readonly type="text" name="nombre" id="nombre1">
                        </div>

                        <div class="form-group col-6 content-justify">
                            <label for="">Apellidos</label>
                            <input style="color:black; background:beige;" style="color:black; background:beige;" class="form-control" readonly type="text" name="apellido" id="apellido1">
                        </div>

                        <div class="form-group col-4 content-justify">
                            <label for="">Usuario</label>
                            <input style="color:black; background:beige;" class="form-control" readonly type="text" name="usuario" id="usuario1">
                        </div>

                        <div class="form-group col-8 content-justify">
                            <label for="">Email</label>
                            <input style="color:black; background:beige;" class="form-control" readonly type="email" name="email" id="email1">
                        </div>
                    </div>
                    <div class="row">

                        <div class="form-group col-4 content-justify">
                            <label for="">Perfil</label>
                            <input style="color:black; background:beige;" class="form-control" readonly type="text" name="perfil1" id="perfil1">
                        </div>

                        <div class="form-group col-4 content-justify">
                            <label for="">Fecha creacion</label>
                            <input style="color:black; background:beige;" class="form-control" readonly type="text" name="fecha" id="fecha1">
                        </div>

                        <div class="form-group col-4 content-justify">
                            <label for="">Estado</label>
                            <input style="color:black; background:beige;" class="form-control" readonly type="text" name="estado" id="estado1">
                        </div>

                    </div>
                </form>
            </div>
        </div>

    </div>
</div>