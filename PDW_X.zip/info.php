Version de PHP:
<hr>
<a href="home.php"><input type="button"  value="Volver"> </a>
<?php
phpinfo();
?>