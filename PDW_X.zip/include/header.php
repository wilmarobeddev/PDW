<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- CSS Style-->
<link rel="stylesheet" href="bootstrap4/css/bootstrap.min.css" />
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" href="css/style.css" />

<link href="bootstrap/fonts/glyphicons-halflings-regular.eot" rel="stylesheet">
  <link href="bootstrap/fonts/glyphicons-halflings-regular.svg" rel="stylesheet">
  <link href="bootstrap/fonts/glyphicons-halflings-regular.ttf" rel="stylesheet">
  <link href="bootstrap/fonts/glyphicons-halflings-regular.woff" rel="stylesheet">
<!-- JS -->
<script src="ajax/libs/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- Icono -->
<link rel="shortcut icon" href="images/cirpro.png">
<!---END spinner-------------->
<!--FIN HEADER--->