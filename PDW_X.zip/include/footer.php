
      <!--FOOTER--->           
      <div class="container-fluid" style="background-color: rgb(9, 9, 9, 0.9); padding:15px; border-top:orange 3px solid; margin-top:auto;">
      <h3 style="text-align: center;    margin:auto;    color: azure;    font-size:x-small;"> © <?php echo date('Y'); ?> | Developer | Prodowork Team</h3>
      </div>
      <!--FIN FOOTER--->   